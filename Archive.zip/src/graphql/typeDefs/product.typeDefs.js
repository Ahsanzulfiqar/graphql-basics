import  {gql} from "apollo-server-express" 



const productTypeDefs =  gql`

    type Query {
    GetAllProducts: [Product!]!
  GetProductById(_id: ID!): Product
  GetVariantsByProduct(productId: ID!): [ProductVariant!]!
  GetVariantById(_id: ID!): ProductVariant

    }


    type Mutation {
        
    CreateProduct( data: CreateProductInput!): Product!
    UpdateProduct(_id: ID!, data: UpdateProductInput!): Product!
    CreateProductVariant(data: CreateProductVariantInput!): ProductVariant!
    UpdateProductVariant(_id: ID!, data: UpdateProductVariantInput!): ProductVariant!

    #  UpdateWarehouse(_id: ID!, data: UpdateWarehouseInput!): String!

    },
type Product {
  _id: ID!
  name: String!
  brand: String!
  sku: String!
  barcode: String
  description: String
  category: String!
  subCategory: String!
  purchasePrice: Float!
  salePrice: Float!
  attributes: [Attribute]
  isActive: Boolean!
  images: [ProductImage]!
  createdAt: String
  updatedAt: String
   # ✅ NEW computed fields
  categoryInfo: CategoryBasic
  subCategoryInfo: SubCategoryBasic
}

type ProductVariant {
  _id: ID!
  product: ID!          # or Product! if you want to populate/resolve
  name: String!
  sku: String!
  barcode: String!
  purchasePrice: Float!
  salePrice: Float!
  attributes: [ProductVariantAttribute!]
  packSize: String
  netWeight: String!
  isActive: Boolean!
  images: [ProductImage!]
  createdAt: String!
  updatedAt: String!
}


type Attribute {
  name: String
  value: String
}

type ProductImage {
  url: String
  alt: String
}



type ProductVariantAttribute {
  name: String
  value: String
}


# --- Input Types ---
input CreateProductInput {
  name: String!
  brand: String!
  sku: String!
  barcode: String
  description: String
  category: String!
  subCategory: String!
  purchasePrice: Float!
  salePrice: Float!
  attributes: [AttributeInput]
  isActive: Boolean!
  images: [ProductImageInput]
  # variants: [CreateProductVariantInlineInput]
}

input UpdateProductInput {
  name: String
  brand: String
  barcode: String
  sku: String
  description: String
  category: String
  subCategory: String
  purchasePrice: Float
  salePrice: Float
  attributes: [AttributeInput]
  isActive: Boolean
  images: [ProductImageInput]
}

input AttributeInput {
  name: String
  value: String
}

input ProductImageInput {
  url: String
  alt: String
}

input ProductVariantAttributeInput {
  name: String
  value: String
}

input CreateProductVariantInput {
  productId: ID!
  name: String!
  sku: String!
  barcode: String
  purchasePrice: Float
  salePrice: Float
  attributes: [ProductVariantAttributeInput!]
  packSize: String
  netWeight: String
  isActive: Boolean
  images: [ProductImageInput!]
}

input UpdateProductVariantInput {
  productId: ID
  name: String
  sku: String
  barcode: String
  purchasePrice: Float
  salePrice: Float
  attributes: [ProductVariantAttributeInput!]
  packSize: String
  netWeight: String
  isActive: Boolean
  images: [ProductImageInput!]
}


# Inline variant spec used only when creating a product
input CreateProductVariantInlineInput {
  name: String!
  sku: String!
  barcode: String
  purchasePrice: Float
  salePrice: Float
  attributes: [ProductVariantAttributeInput!]
  packSize: String
  netWeight: String
  isActive: Boolean
  images: [ProductImageInput!]
}

type CategoryBasic {
  _id: ID!
  name: String!
}

type SubCategoryBasic {
  _id: ID!
  name: String!
}



`
export default productTypeDefs;